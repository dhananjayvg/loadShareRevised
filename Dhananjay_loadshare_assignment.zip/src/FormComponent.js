import React from "react";
import data from "./data";

class FormComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {data: data};
    }

    handleKeyChange = e => {
        const id = e.target.id;
        const keyValue = id.split("-")[1]; 
        const newId = e.target.value;
        const { data } = this.state;
        const value = data[keyValue] ? data[keyValue] : undefined;

        // 1. simple properties
        if(value) {
            data[newId] = value;
            delete data[keyValue];
            this.setState({data: data});
        }
        // 2. nested properties
    };

    handleValueChange = e => {
        const value = e.target.value;
        const key = e.target.id.split("-")[1];
        const { data } = this.state;
        
        //1. simple properties
        if(data[key]) {
            data[key] = value;
        }
        //2. nested properties

        this.setState({data:data});
    };
    
    getField = pair => {
        let valueType = typeof pair.value;
        const { key, value } = pair;
        const checkIfArray = elm => Array.isArray(elm) ? true : false;
        const checkIfObject = elm => typeof elm == "object" && !Array.isArray(elm) ? true : false;
        const returnObject = item => typeof item === "object";

        if(valueType == "object" && checkIfArray(value) && value.findIndex(returnObject)) {
            valueType = "array";
        }

        switch(valueType) {
            case "boolean": {
                const val = (
                    <div>
                        <input type="text" id={`key-${key}`} value={`${key}`} onChange={this.handleKeyChange}/>
                        <input type="checkbox" id={`value-${key}`} checked={`${value}`} onChange={this.handleValueChange}/>
                    </div>
                )
                return val;
            }
            case "number":
            case "string": {
                const val = (
                    <div>
                        <input type="text" id={`key-${key}`} value={`${key}`} onChange={this.handleKeyChange}/>
                        <input type="text" id={`value-${key}`} value={`${value}`} onChange={this.handleValueChange}/>
                    </div>
                );
                return val;
            }
            case "object": {
                if(checkIfArray(value)) {
                    const val = value.map((element, index) => {
                        return this.generateField(`${key}-${index}`, element);
                    });
                    return val;
                }
                else if(checkIfObject(value)) {
                    const val = this.generateFieldsForAll(value);
                    return val;

                }
            }
            case "array": {
                const opts = value.forEach(item => {
                    return (<option value={item}>{item}</option>)}
                );
                const val = (
                    <div>
                        <input type="text" id={`key-${key}`} value={`${key}`}/>
                        <select id={`key-${key}`}>
                            <option value="na">Select option</option>
                            {opts}
                        </select>
                    </div>
                )
                return val;
            }
            default: return(<p>Invalid key/value pair</p>);
        }
    };

    generateField = (key, value) => {
        // simple case
        const field = this.getField({key, value});
        return field;
    };

    generateFieldsForAll = data => {
        const allFields = Object.keys(data).map(item=> {
            return this.generateField(item, data[item]);
        });
        return allFields;
    }

    render() {
        const { data } = this.state;
        const fields = this.generateFieldsForAll(data);
        console.log(data);

        return(
            <div>
                <p>JSON fields will appear below.</p>
                <div>
                    {fields}
                </div>
            </div>
        );
    }
}

export default FormComponent;